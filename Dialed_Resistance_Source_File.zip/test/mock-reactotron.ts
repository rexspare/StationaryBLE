declare const tron // eslint-disable-line @typescript-eslint/no-unused-vars
