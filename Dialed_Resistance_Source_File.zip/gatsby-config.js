module.exports = {
  plugins: [
    `gatsby-plugin-react-native-web`,
    /* ... */
  ],
}
