module.exports = __DEV__ ? require("./env.dev") : require("./env.prod")
