module.exports = {
  imagePath: "./assets/icon.png",

  adaptiveIconBackground: "#636261",
  adaptiveIconForeground: "./assets/icon-foreground.png",
}
